import type { WorldAccess } from "@ngne/core";
import { Bullet, Enemy, Particle, Pickup, Pose } from "../components/combat.ts";
import type { RunState } from "../world/session.ts";
import { COMBAT } from "../config/encounters.ts";
export function spawnEnemy(world: WorldAccess, run: RunState, kind: number, x: number, y: number, options: { vx?: number; pattern?: number; hp?: number; cooldown?: number } = {}) {
  const hp = options.hp ?? [3, 12, 8, COMBAT.bossHp, 35][kind];
  return world.spawn(Pose.of({ x, y, px: x, py: y }), Enemy.of({ kind, hp, maxHp: hp, originX: x,
    cooldown: options.cooldown ?? (kind === 0 ? 1.6 : kind === 1 ? 1.9 : 0.7), vx: options.vx ?? 0,
    pattern: options.pattern ?? 0, radius: [12, 14, 9, 29, 11][kind], id: run.nextId++ }));
}
export function spawnBullet(world: WorldAccess, x: number, y: number, vx: number, vy: number, team = 1, color = 0xff717e, size = 3) {
  return world.spawn(Pose.of({ x, y, px: x, py: y }), Bullet.of({ vx, vy, team, radius: team ? 2.5 : 2, color, size }));
}
export function spawnParticle(world: WorldAccess, x: number, y: number, vx: number, vy: number, life: number, color: number, size = 2, kind = 0) {
  return world.spawn(Pose.of({ x, y, px: x, py: y }), Particle.of({ vx, vy, life, color, size, kind }));
}
export function spawnRepair(world: WorldAccess, x: number, y: number) { return world.spawn(Pose.of({ x, y, px: x, py: y }), Pickup.of()); }
