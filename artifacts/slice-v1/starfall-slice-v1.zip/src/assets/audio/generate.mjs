// Original Starfall synthesis. Re-run with node src/assets/audio/generate.mjs.
// No third-party samples or melodies. PCM exports are consumed through NGNE audioAsset.
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
const rate = 22050;
let seed = 0x5fa11;
function noise() { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 2147483648 - 1; }
const hz = midi => 440 * 2 ** ((midi - 69) / 12);
const output = [];
function buffer(seconds) { return new Float64Array(Math.ceil(seconds * rate)); }
function add(data, at, duration, sample, volume = 1) {
  const start = Math.round(at * rate), count = Math.round(duration * rate);
  for (let i = 0; i < count; i++) {
    const index = start + i;
    if (index >= data.length) break;
    const t = i / rate;
    data[index] += sample(t, i / count) * volume;
  }
}
function tone(data, at, duration, midi, gain, kind = 'lead') {
  const f = hz(midi);
  add(data, at, duration, (t, p) => {
    const envelope = Math.min(1, t / .006) * Math.min(1, (duration - t) / .025);
    const phase = 2 * Math.PI * f * t;
    const wave = kind === 'bass'
      ? Math.sin(phase) + .27 * Math.sin(phase * 2) + .12 * Math.sin(phase * 3)
      : Math.sin(phase + Math.sin(phase * 2) * 1.8 * Math.exp(-t * 8)) * .75 + Math.sin(phase * 1.003) * .25;
    return wave * envelope * (kind === 'bass' ? Math.exp(-t * 4) : .65 + .35 * Math.exp(-t * 10));
  }, gain);
}
function kick(data, at, gain = .55) {
  add(data, at, .24, t => Math.sin(2*Math.PI*(48*t + 2.7*(1-Math.exp(-t*35)))) * Math.exp(-t*20) + noise() * Math.exp(-t*180) * .2, gain);
}
function snare(data, at) {
  let previous = 0;
  add(data, at, .18, t => { const n = noise(); const high = n - previous; previous = n; return high*.45*Math.exp(-t*23) + Math.sin(t*2*Math.PI*170)*Math.exp(-t*34)*.35; }, .28);
}
function hat(data, at, open = false) {
  let previous=0;
  add(data,at,open?.12:.045,t=>{ const n=noise(); const high=n-previous; previous=n; return high*Math.exp(-t*(open?38:95)); },open?.055:.04);
}
function music(name, bpm, boss) {
  const beat = 60 / bpm, bars = 8, data = buffer(beat * 4 * bars);
  const roots = boss ? [38,38,34,36,38,41,34,36] : [38,34,41,36,38,34,41,36];
  const melody = boss ? [0,0,7,10,12,10,7,5,0,3,7,10,7,5,3,5] : [12,7,10,14,12,7,5,7,12,15,14,10,7,10,5,7];
  for(let bar=0;bar<bars;bar++) {
    const root = roots[bar], base = bar*4*beat;
    for(let step=0;step<16;step++) {
      const at=base+step*beat/4;
      if(step%4===0 || (boss && step===10)) kick(data,at);
      if(step===4||step===12) snare(data,at);
      if(step%2===0) hat(data,at,step===14);
      tone(data,at,beat*.20,root+24+[0,7,12,7][step%4],.035,'lead');
      if(step%2===0) {
        tone(data,at,beat*.38,root+((step===6||step===14)?12:0),.20,'bass');
        const m=melody[(step/2+(bar%2)*8)%16];
        tone(data,at,beat*(step===14?.7:.42),root+12+m,boss?.12:.10);
      }
    }
  }
  save(name,data,.88);
}
function save(name,data,peakTarget=.85) {
  let peak=0,sum=0;
  for(const sample of data) peak=Math.max(peak,Math.abs(sample));
  const gain=peak>0?peakTarget/peak:1;
  const wav=Buffer.alloc(44+data.length*2);
  wav.write('RIFF',0); wav.writeUInt32LE(wav.length-8,4); wav.write('WAVEfmt ',8);
  wav.writeUInt32LE(16,16); wav.writeUInt16LE(1,20); wav.writeUInt16LE(1,22);
  wav.writeUInt32LE(rate,24); wav.writeUInt32LE(rate*2,28); wav.writeUInt16LE(2,32); wav.writeUInt16LE(16,34);
  wav.write('data',36); wav.writeUInt32LE(data.length*2,40);
  for(let i=0;i<data.length;i++){const s=Math.max(-1,Math.min(1,data[i]*gain));sum+=s*s;wav.writeInt16LE(Math.round(s*32767),44+i*2);}
  writeFileSync(new URL(name+'.wav',import.meta.url),wav);
  output.push({name:name+'.wav',seconds:data.length/rate,rate,channels:1,peak:peakTarget,rms:Math.sqrt(sum/data.length),bytes:wav.length});
}
music('breakwater',138,false); music('gatebreaker',154,true);
let data=buffer(.105);
add(data,0,.105,t=>Math.sin(2*Math.PI*(1700*t-5000*t*t))*Math.exp(-t*48)+noise()*.10*Math.exp(-t*70)); save('shot',data,.66);
data=buffer(.12); add(data,0,.12,t=>noise()*Math.exp(-t*42)+Math.sin(t*2*Math.PI*640)*Math.exp(-t*55)*.3); save('hit',data,.68);
data=buffer(.65); add(data,0,.65,t=>noise()*Math.exp(-t*9)*.7+Math.sin(2*Math.PI*(42*t+1.8*(1-Math.exp(-t*20))))*Math.exp(-t*8)); save('explosion',data,.92);
data=buffer(.9); add(data,0,.9,t=>noise()*Math.exp(-t*5)*.4+Math.sin(2*Math.PI*(48*t+5*(1-Math.exp(-t*12))))*Math.exp(-t*5));
for(let i=0;i<5;i++)tone(data,i*.07,.32,62+i*5,.20);save('nova',data,.9);
data=buffer(.4); add(data,0,.4,t=>Math.sin(2*Math.PI*(280*t-220*t*t))*Math.exp(-t*10)+noise()*Math.exp(-t*16)*.35);save('damage',data,.8);
data=buffer(1.15); for(let i=0;i<3;i++)add(data,i*.35,.20,t=>Math.sin(2*Math.PI*440*t)+Math.sin(2*Math.PI*587.33*t)*.4,.3);save('warning',data,.75);
data=buffer(1.5); [62,66,69,74].forEach((m,i)=>tone(data,i*.15,.65,m,.4));save('clear',data,.82);
data=buffer(1.25); [50,48,45,38].forEach((m,i)=>tone(data,i*.18,.55,m,.4,'bass'));save('death',data,.78);
writeFileSync(new URL('provenance.json',import.meta.url),JSON.stringify({source:'Original deterministic synthesis in generate.mjs; no external samples or melody sources.',format:'mono PCM16 WAV',files:output},null,2));
console.log(JSON.stringify(output,null,2));
