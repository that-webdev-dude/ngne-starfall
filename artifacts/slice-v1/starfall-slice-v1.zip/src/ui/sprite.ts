import type { Frame } from "@ngne/core";
import type { ArtFrame } from "../services/art-assets.ts";
export function drawSprite(frame: Frame, artwork: ArtFrame, x: number, y: number, layer = 2, alpha = 1, color = 0xffffff): void {
  frame.sprite({ x: x + artwork.width / 2 - artwork.pivotX, y: y + artwork.height / 2 - artwork.pivotY,
    width: artwork.width, height: artwork.height, texture: artwork.texture, u: artwork.u, v: artwork.v,
    uw: artwork.uw, vh: artwork.vh, layer, alpha, color });
}
