import "./style.css";
import { BrowserGame, type PreparedScene } from "@ngne/core";
import { VIEW } from "./config/preview.ts";
import { installDisplay } from "./services/display.ts";
import { artAssets } from "./services/art-assets.ts";
import { combatImageAssets } from "./services/combat-assets.ts";
import { combatAudioAssets, createCombatSound } from "./services/sound.ts";
import { loadBest, loadSettings, saveBest } from "./services/storage.ts";
import { stageScene } from "./scenes/stage.ts";
import { menuScene } from "./scenes/menu.ts";
import type { Progress, ProgressCommand, Session } from "./world/session.ts";

const canvas = document.querySelector<HTMLCanvasElement>("#game")!;
const output = document.querySelector<HTMLPreElement>("#error")!;
const session: Session = { settings: loadSettings(), screen: "title", best: loadBest(), ready: false };
function report(error: unknown): void {
  if (!(error instanceof Error)) return;
  output.hidden = false;
  const detail = error instanceof AggregateError ? `${error.message}\n${error.errors.map(String).join("\n")}` : error.message;
  output.textContent += `${output.textContent ? "\n" : ""}${detail}`;
}
let lastLabel = 0, savedBest = session.best, ducked = false;
const app = new BrowserGame<Progress, ProgressCommand>({
  canvas, ...VIEW, seed: "STARFALL-BREAKWATER-01", state: { best: session.best, runs: 0 },
  transition: (state, command) => ({ best: Math.max(state.best, command.score), runs: state.runs + 1 }),
  clear: 0x060d19, diagnostic: report,
  afterFrame: (stats) => {
    reconcile(); session.best = app.game.state.best;
    if (session.best !== savedBest) { savedBest = session.best; saveBest(savedBest); }
    if (ducked !== (session.screen === "paused")) { ducked = session.screen === "paused"; app.audio.duck(ducked ? 0.22 : 1); }
    app.audio.muted = session.settings.muted;
    if (performance.now() - lastLabel < 150) return;
    lastLabel = performance.now();
    const run = session.run;
    canvas.dataset.screen = session.screen;
    canvas.setAttribute("aria-label", `Starfall. ${session.screen}. ${run ? `Time ${run.seconds.toFixed(1)}. Hull ${run.hull}. Score ${run.score}. Kills ${run.kills}. Phase ${run.phase}. Boss ${Math.round(run.bossHealth)}. Nova ${Math.round(run.nova * 100)} percent. Position ${run.x.toFixed(1)}, ${run.y.toFixed(1)}.` : "Enter or click Launch Flight to begin."} FPS ${Math.round(stats.fps)}. WASD or arrows move. Auto fire. Hold mouse to aim. Space Nova. Escape pause. F fullscreen.`);
  },
});
function take(purpose: string): PreparedScene | undefined {
  const owners = app.game.scenes, owner = owners[owners.length - 1];
  return owner ? app.game.candidates.take(owner.id, purpose) : undefined;
}
const stage = stageScene(session, { assets: [...artAssets, ...combatImageAssets, ...combatAudioAssets], sound: (scene) => createCombatSound(scene, app.audio, session.settings), take });
const title = menuScene("title", session, take), pause = menuScene("pause", session, take), result = menuScene("result", session, take);
function reconcile(): void {
  if (app.game.lifecycle !== "Running") return;
  for (const owner of app.game.scenes) {
    if (owner.definition === "menu-title") app.game.candidates.ensure(owner.id, "play", stage, { key: "first-sortie", retries: 1 });
    if (owner.definition === "orbital-breakwater") {
      app.game.candidates.ensure(owner.id, "pause", pause, { key: "pause", retries: 1 });
      app.game.candidates.ensure(owner.id, "result", result, { key: "result", retries: 1 });
    }
    if (owner.definition === "menu-result") {
      app.game.candidates.ensure(owner.id, "retry", stage, { key: "retry-sortie", retries: 1 });
      app.game.candidates.ensure(owner.id, "title", title, { key: "return-title", retries: 1 });
    }
    if (owner.definition === "menu-pause") app.game.candidates.ensure(owner.id, "title", title, { key: "abandon-title", retries: 1 });
  }
}
const releaseDisplay = installDisplay(canvas);
const unlock = () => { void app.audio.unlock().catch(report); };
canvas.addEventListener("keydown", unlock); canvas.addEventListener("pointerdown", unlock);
window.addEventListener("pagehide", () => {
  releaseDisplay(); canvas.removeEventListener("keydown", unlock); canvas.removeEventListener("pointerdown", unlock);
  void app.dispose().catch(report);
}, { once: true });
try {
  await app.start(await app.game.prepare(title, { key: "title" }));
  session.ready = true; canvas.dataset.ready = "true";
} catch (error) { report(error); }
